                              #####   TAPEX MODEL BUILDING   ######
# TAPEX - Table Pre-training via Learning a Neural SQL Executor
"""
Model Description

TAPEX(Table Pre-training via Execution) is a conceptually simple and empirically powerful pre-training approach to 
empower existing models with table reasoning skills. TAPEX realizes table pre-training by learning a neural SQL 
executor over a synthetic corpus, which is obtained by automatically synthesizing executable SQL queries.

TAPEX is based on the BART architecture, the transformer encoder-decoder(seq2seq) model with a 
bidirectional(BERT-like) encoder and an autoregressive(GPT-like) decoder.
"""

import pandas as pd
from transformers import TapexTokenizer, BartForConditionalGeneration

# Load the CSV file into a DataFrame
table = pd.read_csv(r"C:/Users/manee/OneDrive/Desktop/Project-1/TAPEX Model/10000 Sales Records.csv")

# Display the first few rows of the DataFrame to verify it's loaded correctly
table.head()

# Convert all columns to string to avoid type errors
table = table.astype(str)

# Tokenize the query and table
tokenizer = TapexTokenizer.from_pretrained("microsoft/tapex-large-finetuned-wtq")
model = BartForConditionalGeneration.from_pretrained("microsoft/tapex-large-finetuned-wtq")

# Save the model and tokenizer
tokenizer.save_pretrained("tokenizer")
model.save_pretrained("model")

# Load the saved model and tokenizer
loaded_tokenizer = TapexTokenizer.from_pretrained("tokenizer")
loaded_model = BartForConditionalGeneration.from_pretrained("model")


def predict_with_model(model, tokenizer, table, queries):
    # Initialize an empty list to store predictions
    predictions = []

    # Tokenize the query and table
    max_length = model.config.max_position_embeddings
    for query in queries:
        encoding = tokenizer(table=table, query=query, return_tensors="pt", truncation=True, max_length=max_length)

        # Generate the output
        outputs = model.generate(**encoding)

        # Decode the output and append to predictions
        prediction = tokenizer.batch_decode(outputs, skip_special_tokens=True)
        predictions.append(prediction)

    return predictions

queries = []
while True:
    query = input("Enter a query (or type 'exit' to stop): ")
    if query.lower() == 'exit':
        break
    queries.append(query)

# Tokenize the query and table
max_length = model.config.max_position_embeddings

# Generate and decode predictions for each query
predictions = predict_with_model(model, tokenizer, table, queries)

# Print predictions
for query, prediction in zip(queries, predictions):
    print(f"Query: {query}")
    print(f"Prediction: {prediction}")
    print()