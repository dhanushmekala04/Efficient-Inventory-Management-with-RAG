# pip install transformers

# pip install torch

from transformers import TapexTokenizer, BartForConditionalGeneration

import pandas as pd

from transformers import Trainer, TrainingArguments

table = pd.read_csv('10000 Sales Records.csv')

table = table.astype(str)

query = "which country has lowest total revenue?"

tokenizer = TapexTokenizer.from_pretrained("microsoft/tapex-large-finetuned-wtq")

model =BartForConditionalGeneration.from_pretrained("microsoft/tapex-large-finetuned-wtq")

max_length = model.config.max_position_embeddings

encoding = tokenizer(table=table, query = query, return_tensors="pt", truncation=True, max_length = max_length)

outputs = model.generate(**encoding)

print(tokenizer.batch_decode(outputs, skip_special_tokens=True))

# Function to generate response for a single query
def generate_response(query):
    encoding = tokenizer(table=table, query=query, return_tensors="pt", truncation=True, max_length=max_length)
    outputs = model.generate(**encoding)
    response = tokenizer.batch_decode(outputs, skip_special_tokens=True)[0]
    return response

# Main loop to ask queries
while True:
    query = input("Enter your query (type 'exit' to quit): ")
    if query.lower() == 'exit':
        print("Exiting...")
        break
    else:
        response = generate_response(query)
        print("Response:", response)
        
        
# Initialize variables for evaluation
total_queries = 0
total_correct = 0

# Main loop to ask queries
while True:
    query = input("Enter your query (type 'exit' to quit): ")
    if query.lower() == 'exit':
        print("Exiting...")
        break
    else:
        response = generate_response(query)
        print("Response:", response)

        # Ask user for feedback
        feedback = input("Was the response relevant? (yes/no): ").lower()

        # Update evaluation metrics based on user feedback
        total_queries += 1
        if feedback == "yes":
            total_correct += 1

# Calculate accuracy
accuracy = total_correct / total_queries if total_queries > 0 else 0
print("Model Accuracy:", accuracy)        